/*
This file is part of Snappy Driver Installer Origin.

Snappy Driver Installer Origin is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License or (at your option) any later version.

Snappy Driver Installer Origin is distributed in the hope that it will be useful
but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
Snappy Driver Installer Origin.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "..\source\svnrev.h"

/* test
#undef SVN_REV
#define SVN_REV 829
#undef SVN_REV_STR
#define SVN_REV_STR "829"
*/

#define VER_FILEVERSION             2,0,6,SVN_REV
#define VER_FILEVERSION_STR         "2.0.6." SVN_REV_STR "\0"

#define VER_VERSION_STR             "Version 2.0.6." SVN_REV_STR
#define VER_VERSION_STR2            "v2.0.6"

#define VER_VERSION_FINGERPRINT     "-SO2006-"

#define IDC_STATIC     -1

#define RESFILE       100

#define IDI_ICON1     200
#define IDR_CHECKED   201
#define IDR_THEME     202
#define IDR_LANG      203
#define IDR_LICENSE   204
#define IDR_UP        205
#define IDR_DOWN      206
#define IDR_UP_H      207
#define IDR_DOWN_H    208
#define IDR_INSTALL64 209
#define IDR_CLI_HELP  210
#define IDR_LOGO      211
//#define IDR_PATREON   212
#define IDB_LOGO      214
#define IDB_WATERMARK 215

// Dialogs
#define IDD_DIALOG1   301
#define IDD_DIALOG2   302
#define IDD_DIALOG3   303

// License
#define IDC_EDIT1     304
#define IDACCEPT      305

// Update dialog
#define ID_UPD_LIST        309

#define ID_UPD_PROMPTBOX   340
#define ID_UPD_PROMPT      341
#define ID_UPD_PROGRESSBAR 342

#define ID_UPD_SELECTION   317
#define ID_UPD_CHECKALL    306
#define ID_UPD_UNCHECKALL  307
#define ID_UPD_CHECKTHISPC 308
#define ID_UPD_CHECKNETWORK 316
#define ID_UPD_TOTALSIZE   310
#define ID_UPD_TOTALAVAIL  313
#define ID_UPD_SELECTED    314

#define ID_UPD_STREAM_STATS  330
#define ID_UPD_STREAM_STATE  331
#define ID_UPD_STREAM_SEEDS  332
#define ID_UPD_STREAM_ALERT  333
#define ID_UPD_STREAM_SESSDL 334
#define ID_UPD_STREAM_SESSUL 335
#define ID_UPD_STREAM_COMPLETE 336
#define ID_UPD_STREAM_TIME   337

#define ID_UPD_OPTIONS 322
#define ID_UPD_ONLYUPDATES 311
#define ID_UPD_KEEPSEEDING 312

#define ID_UPD_SPECIALMODE     323
#define ID_UPD_TXT_SHARE       328
#define ID_UPD_BTN_SHARE       325

#define ID_UPD_BTN_UPDATE      324
#define ID_UPD_BTN_STOP        326
#define ID_UPD_BTN_CLOSE       327

// Options dialog
#define IDC_TAB1      380

// View tab
#define IDD_Page1     400
#define IDD_P1_DRV    401
#define IDD_P1_DRV1   402
#define IDD_P1_DRV2   403
#define IDD_P1_DRV3   404

#define IDD_P1_ZOOMG  405
#define IDD_P1_ZOOML  406
#define IDD_P1_ZOOMR  407
#define IDD_P1_ZOOMI  408
#define IDD_P1_ZOOMB  409
#define IDD_P1_ZOOMS  410

#define IDD_P1_HINTG  411
#define IDD_P1_HINTL  412
#define IDD_P1_HINTE  413

// Update tab
#define IDD_Page2     500
#define IDD_P2_TOR    501
#define IDD_P2_PORT   502
#define IDD_P2_CON    503
#define IDD_P2_DOWN   504
#define IDD_P2_UP     505
#define IDD_P2_PORTE  506
#define IDD_P2_CONE   507
#define IDD_P2_DOWNE  508
#define IDD_P2_UPE    509

#define IDD_P2_UPD    510
#define IDD_P2_MINPORTE 511
#define IDD_P2_MAXPORTE 512
#define IDD_P2_MINPORT  513
#define IDD_P2_MAXPORT  514
#define IDD_P2_ONLYUPDATES 515
#define IDD_P2_TORRENTALERTS 516

// Path tab
#define IDD_Page3     600
#define IDD_P3_DIR1   601
#define IDD_P3_DIR2   602
#define IDD_P3_DIR3   603
#define IDD_P3_DIR4   604
#define IDD_P3_DIR5   605
#define IDD_P3_DIR1E  606
#define IDD_P3_DIR2E  607
#define IDD_P3_DIR3E  608
#define IDD_P3_DIR4E  609
#define IDD_P3_DIR5E  610

// Advanced tab
#define IDD_Page4     700
#define IDD_P4_CMDG   701
#define IDD_P4_CMDL   702
#define IDD_P4_CMD1   703
#define IDD_P4_CMD2   704
#define IDD_P4_CMD3   705
#define IDD_P4_CMD1E  706
#define IDD_P4_CMD2E  707
#define IDD_P4_CMD3E  708

#define IDD_P4_CONSL  709

// system menu
#define IDM_ABOUT     16
#define IDM_OPENLOGS  17
#define IDM_LICENSE   18
#define IDM_DRVDIR    19
#define IDM_REBUILDNDX 20
#define IDM_BACKUP_DRV1 21
#define IDM_BACKUP_DRV2 22
#define IDM_TOOLS     24
#define IDM_WELCOME   25
#define IDM_TRANSLATE 26

// About box
#define IDD_ABOUT     800
#define IDD_ABOUT_T1  801
#define IDD_ABOUT_T2  802
#define IDD_ABOUT_T3  803
#define IDD_ABOUT_T4  804
#define IDD_ABOUT_T5  805
#define IDD_ABOUT_T6  806
#define IDD_ABOUT_T7  808
#define IDD_ABOUT_T8  809
#define IDD_ABOUT_T9  810
#define IDC_SYSLINK1  811

// welcome box
#define IDD_WELCOME           900
#define IDD_WELC_TITLE        901
#define IDD_WELC_SUBTITLE     902
#define IDD_WELC_INTRO        903
#define IDD_WELC_INTRO2       904
#define IDD_WELC_BUTTON1      905
#define IDD_WELC_BUTTON1_DESC 906
#define IDD_WELC_BUTTON2      907
#define IDD_WELC_BUTTON2_DESC 908
#define IDD_WELC_BUTTON3      909
#define IDD_WELC_BUTTON3_DESC 910
#define IDD_WELC_CLOSE        911
#define IDD_WELC_LINK1        912
#define IDD_WELC_LINK2        913
#define IDD_WELC_TEXT         920

// translation tool
#define IDD_TRANSL_EDITDIALOG 1000
#define IDC_TRANSL_KEYVALUE   1001
#define IDC_TRANSL_EDIT1      1002
#define IDC_TRANSL_LANGUAGEID 1003
#define IDC_TRANSL_EDIT2      1010
#define IDC_TRANSL_COPYCLIP   1011
#define IDC_TRANSL_CLEAR      1012

#define WEB_HOMEPAGE    L"www.glenn.delahoy.com/snappy-driver-installer-origin"
